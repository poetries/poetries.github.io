
/*数据库配置文件*/
var app={
    dbUrl: 'mongodb://localhost:27017/',
    dbName: 'graphql' // 数据库名
}

module.exports=app;