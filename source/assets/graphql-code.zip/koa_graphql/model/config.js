
var app={
    dbUrl: 'mongodb://localhost:27017/',
    dbName: 'koa-demo'
}

module.exports=app;